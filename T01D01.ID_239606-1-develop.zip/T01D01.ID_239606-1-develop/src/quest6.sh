sh keygen.sh
rm key/file*
sh unifier.sh
