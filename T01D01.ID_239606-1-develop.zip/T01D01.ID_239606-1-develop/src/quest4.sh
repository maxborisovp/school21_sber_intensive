ps
kill 41168
kill -9 $(pgrep -f ai_door_control.sh)
